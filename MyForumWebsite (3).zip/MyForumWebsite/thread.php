<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <title>I-Discuss</title>
</head>
<body>
 <!-- Include the navigation -->
 <?php include 'partials/header.php';?>
 <div class="container my-4" id="ques">
     <!-- Jumbotron for thread details -->
     <?php 
        include 'partials/_dbconnect.php';
         
        $id = $_GET['thread_id'];
        $sql = "SELECT * FROM `threads` WHERE thread_id = $id";
        $result = mysqli_query($conn, $sql);
        
        while ($row = mysqli_fetch_assoc($result)) {            
            $title = $row['thread_title'];
            $disc = $row['thread_disc'];
        }
        
        $showAlert = false; // Initialize showAlert variable

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method == 'POST') {
          $comment = $_POST['comment'];
          $sql = "INSERT INTO `comments` (`comment_content`, `thread_id`, `comment_time`) VALUES ('$comment', $id, current_timestamp())";
          $result = mysqli_query($conn, $sql);
          if ($result) {
            $showAlert = true; 
          } else {
            echo "Insertion failed: " . mysqli_error($conn);
          }
        }
        ?>
        <div class="jumbotron">
          <h1 class="display-4"><?php echo $title; ?></h1>
          <p class="lead"><?php echo $disc; ?></p>
          <!-- <p class="lead">Posted By: -->
          <p>

          
          </p>
        </div>
    </div>
    
<div class="container">
  <form action="" method="post">
    <div class="form-group">
      <label for="comment">Explain Comment</label>
      <textarea name="comment" class="form-control" id="comment" placeholder="Explain Comment"></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  
  <h1>Comments</h1>
  <?php
  // Display comments for the thread
  // $email = $_GET['myemail'];
  $sql = "SELECT * FROM `comments` WHERE thread_id = $id";
  $result = mysqli_query($conn, $sql);
  
  while ($row = mysqli_fetch_assoc($result)) {
    $content = $row['comment_content'];
     echo '<div class="media">
    <img class="mr-3" src="man.jpg" alt="Phone Contact Icon" height="40" width="40">
    <div class="media-body">
        <h5 class="mt-0">' .$content. '</h5>
        <p>
        </p>
    </div>
</div>';
    
  }
  ?>
</div>

<?php include 'partials/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
