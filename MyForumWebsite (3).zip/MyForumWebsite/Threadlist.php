<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <title>I-Discusss</title>
</head>
<body>
 <!-- Here We are put The navigation -->
 <?php include 'partials/header.php';?>
 
 <div class="container my-4" id="ques">
     <!-- Putting the jumbotron -->
     <?php 
        include 'partials/_dbconnect.php';
         
        $id = $_GET['catid'];
        $sql = "SELECT * FROM `category` WHERE category_id=$id ";
        $result = mysqli_query($conn, $sql);
        
        while ($row = mysqli_fetch_assoc($result)) {            
            $cat_dis = $row['category_discuss'];
            $cat_name = $row['category_name'];
        }
        
$showAlert = true;
$method = $_SERVER['REQUEST_METHOD'];
if ($method == 'POST') {
  $title = $_POST['title'];
  $disc = $_POST['desc'];
  $sql = "INSERT INTO `threads`(`thread_title`, `thread_disc`, `thread_cat_id`, `timestamp`, `thread_user_id`) VALUES ('$title', '$disc', $id, current_timestamp(), 0)";
  
  $result = mysqli_query($conn, $sql);
   $showAlert = true;
  if ($showAlert) {
       echo '<div class="alert alert-success" role="alert">
       <h4 class="alert-heading">Success</h4>
       <p>Your Quation is Successfully posted.</p>
     </div>';
  } else {
    // Handle the case where the INSERT query failed.
    echo "Insertion failed: " . mysqli_error($conn);
  }
}

        
        
        
echo '<div class="jumbotron">
<h1 class="display-4"> Welcome to ' . $cat_name . '</h1>
<p class="lead"> ' . $cat_dis . '.</p>
<p class="lead">
<a class="btn btn-success btn-lg" href="#" role="button">Learn more</a>
</p>
</div>
</div>';
?>  
<!-- if There is no Quation then  -->

<div class="container">
  <h1>Ask a Quastion</h1>
  <form action="#" method="post">
  <div class="form-group">
    <label for="title">Problem Title</label>
    <input type="text" name="title" class="form-control" id="title" aria-describedby="titleHelp" placeholder="Problem Title">
    <small id="titleHelp" class="form-text text-muted">Keep your title.</small>
  </div>
  <div class="form-group">
    <label for="desc">Problem Description</label>
    <textarea name="desc" class="form-control" id="desc" placeholder="Problem Description"></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

</div>
<div class="container">
<h1>Browse Quation</h1>
<?php
$id = $_GET['catid'];
$myemail = $_GET['myemail'];
$sql = "SELECT * FROM `threads` WHERE thread_cat_id = $id";

$result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
      $disc = $row['thread_disc'];
        $title = $row['thread_title'];
        $id = $row['thread_id'];

        echo '<div class="media">
            <img class="mr-3" src="man.jpg" alt="Phone Contact Icon" height="40" width="40">
            <div class="media-body">
                <h5 class="mt-0"><a href="thread.php?thread_id='.$id.' & myemail='.$myemail.'">' . $title . ' </a></h5>

                ' . $disc . '
            </div>
        </div>';
    }

?>

<?php include 'partials/footer.php'?>
  <!-- <img class="d-block w-100" src="https://source.unsplash.com/random/500x190/?development" alt="Third slide"> -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>