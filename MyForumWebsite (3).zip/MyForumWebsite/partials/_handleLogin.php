<?php
session_start(); // Start the session

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include '_dbconnect.php';
    $showError = "false";
    $loginsuccess = false;
    $email = $_POST['email_id'];
    $pass = $_POST['password_pass'];

    $sql = "SELECT * FROM `sign_in` WHERE `email` = '$email' and `password` = '$pass'";
    $result = mysqli_query($conn, $sql);
    $numRow = mysqli_num_rows($result);

    if ($numRow == 1) {
        $row = mysqli_fetch_assoc($result);
        $loginsuccess = true;
        header("Location: /MYFORUMWEBSITE/index.php?loginsuccess=true");
        exit();

    } else {
        header("Location: /MYFORUMWEBSITE/index.php?loginfalse=false&error=$showError");
    }

    exit();
}
?>
