<?php

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    include '_dbconnect.php';
    
    $showError = "false";
            
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];
    $signtr = false;
    $existSql = "SELECT * FROM `sign_in` WHERE `email` = '$email'";
    
    $results = mysqli_query($conn, $existSql);
    $numRow = mysqli_num_rows($results);
    
    if ($numRow > 0) {
        header("Location: /MYFORUMWEBSITE/index.php?signupsuccess=false&error=$showError");
    }
    else {
        // $sql = "INSERT INTO `sign_in` (`email`, `mobile`, `password`) VALUES ('$email', '$mobile', '$password')";
        $sql = "INSERT INTO `sign_in` (`email`, `mobile`, `password`) VALUES ('$email', '$mobile', '$password')";

        $result = mysqli_query($conn, $sql);
        // echo "$results";
        if ($result) {
            $signtr = true;
            $showAlert = true;
            header("Location: /MYFORUMWEBSITE/index.php?signupsuccess=true &signtr=true &myemail=$email");
            exit();
            
        }
    }
    header("Location: /MYFORUMWEBSITE/index.php?signupsuccess=false&error=$showError");
}
?>