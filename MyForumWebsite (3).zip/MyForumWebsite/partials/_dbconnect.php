<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "descuss";

$conn = mysqli_connect($servername,$username,$password,$database);

if (!$conn) {
    die ("We are fatching problem to connect database");
}
?>