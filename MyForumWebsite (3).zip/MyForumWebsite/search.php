<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <!-- <link rel="stylesheet" href="style.css"> -->
  <title>I-Discusss</title>
  <style>
    /* .cards { */
        .result{
            /* margin-top:20px; */
            /* padding :20px; */
            margin-top: 40px;
        }
    /* } */
</style>

</head>
<body>
 <!-- Include the navigation -->
 <?php include 'partials/_dbconnect.php'; ?>
   <?php include 'partials/header.php'; ?>
<div class="container my-3">
    <h1>Search result for <?php echo $_GET['search']?></h1>
    <div class="result">
        
        <?php 
    include 'partials/_dbconnect.php';
    $query = $_GET['search'];
    $sql = "SELECT * FROM `threads` WHERE MATCH (`thread_title`, `thread_disc`) AGAINST ('$query')";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $title = $row['thread_title'];
            $disc = $row['thread_disc'];
            $thread_id = $row['thread_id'];
            $url = "thread.php?thread_id=".$thread_id;
        echo '<div class="result">
            <h3><a href="'.$url.'"class="text-dark">'.$title.'</a> </h1>
            <p>'.$disc.'</p>
            </div>';
        }   
    }
    
    ?>
</div>
</div>



<!-- Category container starts here -->


<?php include 'partials/footer.php'; ?>
  
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPx
